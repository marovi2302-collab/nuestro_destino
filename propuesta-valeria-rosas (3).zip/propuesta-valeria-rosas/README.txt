INSTRUCCIONES RÁPIDAS
======================

1) Coloca tus archivos en la carpeta assets/:
   - Música instrumental: assets/belanova_instrumental.mp3
   - Foto del momento del SÍ: assets/valeria_si.jpg

2) Abre el archivo index.html con doble clic, o en Visual Studio Code usando la extensión Live Server.

3) Si publicas en Netlify o GitHub Pages, sube toda la carpeta y comparte el enlace.

— Esta versión incluye:
   • Pétalos de rosas cayendo (suaves)
   • Corazones y confetti (paleta pastel)
   • Música (requiere interacción del usuario)
   • Pantalla especial al decir “¡Sí, acepto!” con la foto
